DELIMETER $$
CREATE PROCEDURE AddNum(
@Num1 INT,
@Num2 INT,
@Sum INT OUTPUT
)
AS
BEGIN

SET @Sum=@Num1+@Num2;
END $$
DELIMETER ;
Call AddNum(60,70,@Sumis);
select @Sumis;
