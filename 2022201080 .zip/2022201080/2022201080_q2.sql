DELIMITER //
CREATE PROCEDURE CusName (IN City varchar(33))
BEGIN
select CusName.CUST_NAME from customer where customer.WORKING_AREA=City;
END//
DELIMITER;

