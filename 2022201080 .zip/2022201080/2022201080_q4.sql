DELIMETER $$
DECLARE
@CustomName VARCHAR(20),
@CustomCity VARCHAR(20),
@CustomCountry VARCHAR(20),
@CustomGrade   VARCHAR(20)

DECLARE CurDisp CURSOR 
FOR SELECT 
CustomName,
CustomCity,
CustomCountry,
CustomGrade
FROM
customer
WHERE customer.AGENT_CODE="A00";
OPEN CurDisp;
FETCH NEXT FROM CurDisp INTO
@CustomName,
@CustomCity,
@CustomCountry, 
@CustomGrade

WHILE @@FETCH_STATUS=0
BEGIN
Print(@CustomName);
Print(@CustomCity);
Print(@CustomCountry);
Print(@CustomGrade);
FETCH NEXT FROM CurDisp INTO
@CustomName,
@CustomCity, 
@CustomCountry, 
@CustomGrade
END
CLOSE CurDisp;$$
DELIMETER;
